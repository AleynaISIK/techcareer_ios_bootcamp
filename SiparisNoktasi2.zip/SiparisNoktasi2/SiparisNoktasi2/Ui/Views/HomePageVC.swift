//
//  HomePageVC.swift
//  SiparisNoktasi2
//
//  Created by Aleyna IŞIK on 18.10.2023.
//

import UIKit
import RxSwift
import Kingfisher

class HomePageVC: UIViewController {
  
  @IBOutlet weak var searchBar: UISearchBar!
  
  @IBOutlet weak var yemek_listesi_collectionView_outlet: UICollectionView!{
    didSet{
      yemek_listesi_collectionView_outlet.delegate = self
      yemek_listesi_collectionView_outlet.dataSource = self
    }
  }
  
  var yemeklerListesi = [Yemekler]()
  
  var viewModel = HomePageViewModel()
  
  override func viewWillAppear(_ animated: Bool) {
    viewModel.yemekleriYukle()
  }
  

  override func viewDidLoad() {
    super.viewDidLoad()
    
    searchBar.delegate = self//Anasayfa > UISearchBarDelegate
    
    
    
    
    let tasarim = UICollectionViewFlowLayout()
    tasarim.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    tasarim.minimumLineSpacing = 5 //dikey boşluk
    tasarim.minimumInteritemSpacing = 5 //yataydaki boşluk
    
    //    10 x 10 x 10 = 30
    //    15 x 10 x 10 x 15 = 50 --> 3 itemlı yaparsak  --> tasarim.sectionInset = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15) ekran genislikten 50 yi çıkartıp 3 e böleceğiz.
    let ekranGenislik = UIScreen.main.bounds.width
    let itemGenislik = (ekranGenislik - 30) / 2
    
    tasarim.itemSize = CGSize(width: itemGenislik , height: 143)
    
    yemek_listesi_collectionView_outlet.collectionViewLayout = tasarim
    
    _ = viewModel.yemekListesi.subscribe(onNext: { liste in
      self.yemeklerListesi = liste
      DispatchQueue.main.async {
        self.yemek_listesi_collectionView_outlet.reloadData()
      }
    })
  }

  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      if segue.identifier == "toDetay"{
          if let yemek = sender as? Yemekler{
              let gidilecekVC = segue.destination as! DetailVC
              gidilecekVC.yemek = yemek
          }
      }
  }
}

extension HomePageVC : UISearchBarDelegate {
  func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
    viewModel.ara(aramaKelimesi: searchText)
  }
}

extension HomePageVC: UICollectionViewDelegate, UICollectionViewDataSource{
  
  
  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    print("burda")
    if collectionView == yemek_listesi_collectionView_outlet {
      return yemeklerListesi.count
    }
    return yemeklerListesi.count
  }
  
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    if collectionView == yemek_listesi_collectionView_outlet {
      
      let cell = yemek_listesi_collectionView_outlet.dequeueReusableCell(withReuseIdentifier: "yemekListesiCollectionViewCell", for: indexPath) as! yemekListesiCollectionViewCell
      
      let yemekler = yemeklerListesi[indexPath.row]
      
      
      cell.yemek_adi_label_outlet.text = "\(yemekler.yemek_adi!) "
      cell.yemek_fiyat_label_outlet.text = "\(yemekler.yemek_fiyat!).00 ₺"
      
      if let url = URL(string: "http://kasimadalan.pe.hu/yemekler/resimler/\(yemekler.yemek_resim_adi!)")
      {
        DispatchQueue.main.async {
          cell.imageview_outlet.kf.setImage(with : url)
        }
      }
      return cell
    }else{
      let cell = yemek_listesi_collectionView_outlet.dequeueReusableCell(withReuseIdentifier: "yemekListesiCollectionViewCell", for: indexPath) as! yemekListesiCollectionViewCell
      
      return cell
      
    }
  }
  
  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    let yemek = yemeklerListesi[indexPath.row]
    performSegue(withIdentifier: "toDetay", sender: yemek)
    print("Tıklandı\(indexPath.row)")
  }
}
