//
//  SepetVC.swift
//  SiparisNoktasi2
//
//  Created by Aleyna IŞIK on 19.10.2023.
//

import UIKit
