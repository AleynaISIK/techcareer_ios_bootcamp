//
//  yemekListesiCollectionViewCell.swift
//  SiparisNoktasi2
//
//  Created by Aleyna IŞIK on 18.10.2023.
//

import UIKit

class yemekListesiCollectionViewCell: UICollectionViewCell {
    
  @IBOutlet weak var imageview_outlet: UIImageView!
  @IBOutlet weak var yemek_adi_label_outlet: UILabel!
  @IBOutlet weak var yemek_fiyat_label_outlet: UILabel!
}
