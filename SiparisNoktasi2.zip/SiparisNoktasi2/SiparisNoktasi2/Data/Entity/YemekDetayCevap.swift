//
//  YemekDetayCevap.swift
//  bitirmeProjesi
//
//  Created by Macbook Pro on 20.10.2022.
//

import Foundation

class YemekDetayCevap : Codable {
    var sepet_yemekler : [YemekDetay]?
    var success : Int?
}
