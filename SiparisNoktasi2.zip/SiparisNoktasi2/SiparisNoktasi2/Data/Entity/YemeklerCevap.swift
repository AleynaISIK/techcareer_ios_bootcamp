//
//  YemeklerCevap.swift
//  bitirmeProjesi
//
//  Created by Macbook Pro on 20.10.2022.
//

import Foundation

class YemeklerCevap : Codable{
    var yemekler : [Yemekler]?
    var success : Int?
}
