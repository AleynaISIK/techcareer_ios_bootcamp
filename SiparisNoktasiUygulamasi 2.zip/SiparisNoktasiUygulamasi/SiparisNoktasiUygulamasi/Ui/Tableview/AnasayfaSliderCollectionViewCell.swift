//
//  AnasayfaSliderCollectionViewCell.swift
//  SiparisNoktasiUygulamasi
//
//  Created by Aleyna IŞIK on 21.10.2023.
//

import UIKit

class AnasayfaSliderCollectionViewCell: UICollectionViewCell {
    
  @IBOutlet weak var imageView: UIImageView!
}
