//
//  DetayVC.swift
//  SiparisNoktasiUygulamasi
//
//  Created by Aleyna IŞIK on 06.10.2023.
//

import UIKit

class DetayVC: UIViewController {
  
  var viewModel  = DetayViewModel()
  var yemek      : Yemekler?
  var yemekDetay = [YemekDetay]()
  var izinKontrol = false

  
  @IBOutlet weak var yemekImageview: UIImageView!
  @IBOutlet weak var yemekAdiLabel: UILabel!
  @IBOutlet weak var AdetLabel: UILabel!
  @IBOutlet weak var ucretLabel: UILabel!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    UNUserNotificationCenter.current().delegate = self
    
    UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge],completionHandler: { granted,error in
      self.izinKontrol = granted
      if granted{
        print("İzin alma işlemi başarılı")
      }else{
        print("İzin alma işlemi başarısız")
      }
      
    })
    
    viewModel.sepetiGuncelle(kullanici_adi: "Aleyna")
    _ = viewModel.yemekDetayListe.subscribe(onNext: { liste in
      self.yemekDetay = liste
    })
    
    if let resim = yemek{
      yemekAdiLabel.text   = resim.yemek_adi
      
      _ = viewModel.toplamUcret.subscribe(onNext: { ucret in
        self.ucretLabel.text = "\(ucret),00 ₺"
      })
      _ = viewModel.siparisMiktari.subscribe(onNext: { adet in
        self.AdetLabel.text = " Adet: \(adet)"
      })
      ucretLabel.text = " \(resim.yemek_fiyat!),00 ₺"
      
      if let url = URL(string: "http://kasimadalan.pe.hu/yemekler/resimler/\(resim.yemek_resim_adi!)")
      {
        DispatchQueue.main.async {
          self.yemekImageview.kf.setImage(with : url)
        }
      }
    }
  }
  
  @IBAction func buttonBildirimOlustur(_ sender: Any) {
    if izinKontrol{
      let icerik = UNMutableNotificationContent()
      icerik.title = "Sipariş Noktası"
      icerik.subtitle = "İndirim Fırsatı"
      icerik.body = "\(yemek?.yemek_adi ?? "Yemek Adı Belirtilmemiş") yanına ekstra yemekler yarı fiyatına.. "
      icerik.badge = 1
      icerik.sound = UNNotificationSound.default
      
      //      1 dk - 60sn sınırı var
      //      let tetikleme = UNTimeIntervalNotificationTrigger(timeInterval: 60, repeats: true)
      let tetikleme = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
      
      
      let istek = UNNotificationRequest(identifier: "id", content: icerik, trigger: tetikleme)
      UNUserNotificationCenter.current().add(istek)
    }
  }
  
  @IBAction func siparisMiktariButton(_ sender: UIButton) {
    viewModel.adetHesapla(sender: sender)
    viewModel.toplamUcretiHesapla(ucret: Int((yemek?.yemek_fiyat)!)!)
  }
  
  @IBAction func vazgecButton(_ sender: Any) {
    dismiss(animated: true)
  }
  
  
  @IBAction func addToCart(_ sender: Any) {
    viewModel.sepeteKontrolluEkleme(yemekDetay: yemekDetay, yemek: yemek, viewModel: viewModel)
    dismiss(animated: true)
  }
}

extension DetayVC : UNUserNotificationCenterDelegate{
  func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
    
    completionHandler([.banner,.sound,.badge])
    
  }
  
}
