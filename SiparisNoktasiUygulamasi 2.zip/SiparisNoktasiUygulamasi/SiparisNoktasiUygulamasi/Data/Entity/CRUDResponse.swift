//
//  CRUDResponse.swift
//  SiparisNoktasiUygulamasi
//
//  Created by Aleyna IŞIK on 05.10.2023.


import Foundation

class CRUDResponse:Codable{
    var success: Int?
    var message: String?
}
