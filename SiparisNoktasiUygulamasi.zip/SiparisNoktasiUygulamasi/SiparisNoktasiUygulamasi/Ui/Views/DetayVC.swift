//
//  DetayVC.swift
//  SiparisNoktasiUygulamasi
//
//  Created by Aleyna IŞIK on 06.10.2023.
//

import UIKit

class DetayVC: UIViewController {
  
  var viewModel  = DetayViewModel()
  var yemek      : Yemekler?
  var yemekDetay = [YemekDetay]()
  
  @IBOutlet weak var yemekImageview: UIImageView!
  @IBOutlet weak var yemekAdiLabel: UILabel!
  @IBOutlet weak var AdetLabel: UILabel!
  @IBOutlet weak var ucretLabel: UILabel!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    viewModel.sepetiGuncelle(kullanici_adi: "Aleyna")
    _ = viewModel.yemekDetayListe.subscribe(onNext: { liste in
      self.yemekDetay = liste
    })
    
    if let y = yemek{
      yemekAdiLabel.text   = y.yemek_adi
      
      _ = viewModel.toplamUcret.subscribe(onNext: { price in
        self.ucretLabel.text = "\(price),00 ₺"
      })
      _ = viewModel.siparisMiktari.subscribe(onNext: { q in
        self.AdetLabel.text = " Adet: \(q)"
      })
      ucretLabel.text = " \(y.yemek_fiyat!),00 ₺"
      
      if let url = URL(string: "http://kasimadalan.pe.hu/yemekler/resimler/\(y.yemek_resim_adi!)")
      {
        DispatchQueue.main.async {
          self.yemekImageview.kf.setImage(with : url)
        }
      }
    }
  }
  
  
  @IBAction func siparisMiktariButton(_ sender: UIButton) {
    viewModel.adetHesapla(sender: sender)
    viewModel.toplamUcretiHesapla(price: Int((yemek?.yemek_fiyat)!)!)
  }
  
  @IBAction func vazgecButton(_ sender: Any) {
    dismiss(animated: true)
  }
  
  
  @IBAction func addToCart(_ sender: Any) {
    viewModel.sepeteKontrolluEkleme(yemekDetay: yemekDetay, yemek: yemek, viewModel: viewModel)
    dismiss(animated: true)
  }
}

